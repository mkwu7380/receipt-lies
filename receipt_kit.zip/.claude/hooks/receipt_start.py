#!/usr/bin/env python3
"""Run FIRST. Records what each artefact looks like BEFORE the task starts."""
import hashlib, json, os, sys, time

def digest(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

root = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
items = []
for p in sys.argv[1:]:
    a = os.path.abspath(p)
    ex = os.path.isfile(a)
    items.append({"path": a, "existed": ex, "size": os.path.getsize(a) if ex else 0, "sha256": digest(a) if ex else None})
os.makedirs(f"{root}/.receipts", exist_ok=True)
json.dump({"t0": time.time(), "items": items}, open(f"{root}/.receipts/contract.json", "w"), indent=1)
print(f"contract written: {len(items)} artefact(s)")
