#!/usr/bin/env python3
"""Stop hook = the three questions of the reel.
  Q1 which file should this task produce?   (declared before the work)
  Q2 was it modified during this run?       (mtime >= start time)
  Q3 did the content really change?         (not empty; sha256 differs from before)
Any one unanswered = the task failed."""
import hashlib, json, os, sys, time

def digest(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

root = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
contract = f"{root}/.receipts/contract.json"
event = json.load(sys.stdin)
if not os.path.exists(contract):
    sys.exit(0)                                   # no contract = nothing to verify

c = json.load(open(contract))
fails = []
if not c["items"]:
    fails.append("Q1 FAIL: no output file was declared (which file should this task produce?)")
for it in c["items"]:
    p = it["path"]
    if not os.path.isfile(p) or os.path.getmtime(p) < c["t0"]:
        fails.append(f"Q2 FAIL: {p} was not modified during this run (missing, or older than the start time)")
    elif os.path.getsize(p) == 0:
        fails.append(f"Q3 FAIL: {p} is empty")
    elif it["existed"] and digest(p) == it["sha256"]:
        fails.append(f"Q3 FAIL: {p} has identical content to before the run")

with open(f"{root}/.receipts/log.txt", "a") as log:
    log.write(f"{time.strftime('%F %T')} stop_hook_active={event.get('stop_hook_active')} fails={len(fails)}\n")

if not fails:
    os.replace(contract, f"{root}/.receipts/last_ok.json")    # verified: retire the contract
    sys.exit(0)

if event.get("stop_hook_active"):                 # already retried once: never loop forever
    open(f"{root}/.receipts/FAILED.txt", "w").write("\n".join(fails) + "\n")
    print(json.dumps({"systemMessage": "Receipt check STILL failing, see .receipts/FAILED.txt"}))
    sys.exit(0)

print(json.dumps({"decision": "block",
                  "reason": "Receipt check failed. Do NOT report success. Fix it or say plainly what is missing:\n" + "\n".join(fails)}))
