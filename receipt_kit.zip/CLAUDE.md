## Receipts (verify before you say "done")
Q1 - Before any task that must create or change a file, DECLARE which file(s) it should produce:
  python3 .claude/hooks/receipt_start.py <file> [<file> ...]
Never report a task as done. A Stop hook then asks Q2 (was the file modified during this run?) and
Q3 (did its content really change?) and will send you back to work if any answer is no.
